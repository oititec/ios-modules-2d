//
//  OILiveness2D.h
//  OILiveness2D
//
//  Created by Thiago Cavalcante on 13/12/22.
//

#import <Foundation/Foundation.h>

//! Project version number for OILiveness2D.
FOUNDATION_EXPORT double OILiveness2DVersionNumber;

//! Project version string for OILiveness2D.
FOUNDATION_EXPORT const unsigned char OILiveness2DVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OILiveness2D/PublicHeader.h>


